## To excute the program type: 
```dotnet build```
```dotnet test```

## Required modules:
dotnet 8.0/9.0

Microsoft.NET.Test.Sdk
MSTest
Selenium.Support
Selenium.WebDriver
Selenium.WebDriver.ChromeDriver
